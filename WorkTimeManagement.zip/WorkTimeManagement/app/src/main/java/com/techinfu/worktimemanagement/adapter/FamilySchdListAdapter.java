package com.techinfu.worktimemanagement.adapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.techinfu.worktimemanagement.R;
import com.techinfu.worktimemanagement.pojo.FamilySchdPojo;
import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;

import java.util.ArrayList;

public class FamilySchdListAdapter extends RecyclerView.Adapter<FamilySchdListAdapter.ViewHolder>  {
    private final ArrayList<FamilySchdPojo> familyschdList;
    private Context context;

    public FamilySchdListAdapter(ArrayList<FamilySchdPojo> listReceived,Context context) {
        this.familyschdList = listReceived;
        this.context=context;
    }

    @NonNull
    @Override
    public FamilySchdListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.health_schd_list_item, parent, false);
        return new FamilySchdListAdapter.ViewHolder(listItem);
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final FamilySchdListAdapter.ViewHolder holder, int position) {
        try{
            final FamilySchdPojo familySchdPojo = familyschdList.get(position);
            holder.titleTV.setText(familySchdPojo.getTitle());
            holder.dateTV.setText(familySchdPojo.getDate());
            holder.timelineTV.setText("From "+familySchdPojo.getStartTime()+" To "+familySchdPojo.getEndTime());
            holder.priorityTV.setText(setPriority(familySchdPojo.getPriority()));

            String isDone = familySchdPojo.getDone();
            if(isDone==null){
                isDone="No";
            }
            if(isDone.equals("Yes")){
                holder.doneCB.setChecked(true);
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_gray));
            }else{
                holder.doneCB.setChecked(false);
            }

            int priority = familySchdPojo.getPriority();
            if(priority==1){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_red));
            }else if (priority==2){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_yellow));
            }else{
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_green));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String setPriority(int priority) {
        String name ="";
        if(priority==3){
            name="LOW";
        }else if(priority==1){
            name="HIGH";
        }else if(priority==2){
            name="MEDIUM";
        }
        return name;
    }

    @Override
    public int getItemCount() {
        return familyschdList.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView titleTV,dateTV,timelineTV,priorityTV;
        private CheckBox doneCB;
        private CardView itemCardView;
        ViewHolder(View itemView) {
            super(itemView);
            this.titleTV=itemView.findViewById(R.id.textViewTitile);
            this.dateTV = itemView.findViewById(R.id.textViewDate);
            this.timelineTV = itemView.findViewById(R.id.textViewTimeLine);
            this.priorityTV =itemView.findViewById(R.id.textViewPriority);
            this.doneCB = itemView.findViewById(R.id.checkBox);
            this.itemCardView = itemView.findViewById(R.id.itemCardView);
        }
    }


}

