package com.techinfu.worktimemanagement.helper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.techinfu.worktimemanagement.pojo.FamilySchdPojo;
import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;

import java.util.ArrayList;

public class FamilySchd_Helper {
    public ArrayList getScheduleList(SQLiteDatabase database) {
        ArrayList productList= new ArrayList<>();
        try{
            productList.clear();
            String selectQuery = "select Id,Title,StartTime,EndTime,Priority,Alarm,Done,Date from family_schedule ORDER BY Id";
            Cursor mcursor = database.rawQuery(selectQuery, null);
            if (mcursor.moveToFirst()) {
                do {
                    FamilySchdPojo healthSchdPojo=new FamilySchdPojo();
                    healthSchdPojo.setId(mcursor.getInt(mcursor.getColumnIndexOrThrow("Id")));
                    healthSchdPojo.setTitle(mcursor.getString(mcursor.getColumnIndexOrThrow("Title")));
                    healthSchdPojo.setDate(mcursor.getString(mcursor.getColumnIndexOrThrow("Date")));
                    healthSchdPojo.setStartTime( mcursor.getString(mcursor.getColumnIndexOrThrow("StartTime")));
                    healthSchdPojo.setEndTime(mcursor.getString(mcursor.getColumnIndexOrThrow("EndTime")));
                    healthSchdPojo.setDone(mcursor.getString(mcursor.getColumnIndexOrThrow("Done")));
                    healthSchdPojo.setPriority(mcursor.getInt(mcursor.getColumnIndexOrThrow("Priority")));
                    healthSchdPojo.setAlarm(mcursor.getString(mcursor.getColumnIndexOrThrow("Alarm")));
                    productList.add(healthSchdPojo);
                } while (mcursor.moveToNext());
            }
            mcursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productList;
    }

    //This method will add new Product
    public String addEvent(SQLiteDatabase database, FamilySchdPojo familySchdPojo){
        ContentValues values = new ContentValues();
        values.put("Title", familySchdPojo.getTitle());
        values.put("Date", familySchdPojo.getDate());
        values.put("StartTime",familySchdPojo.getStartTime());
        values.put("EndTime",familySchdPojo.getEndTime());
        values.put("Priority",familySchdPojo.getPriority());
        database.insert("family_schedule", null, values);
        return "SUCCESS";
    }

    //This method will add new Product
    public String updateEvent(SQLiteDatabase database,FamilySchdPojo familySchdPojo){
        String whereclause = "Id=?";
        String[] whereargs = {String.valueOf(familySchdPojo.getId())};
        ContentValues values = new ContentValues();
        values.put("Done", familySchdPojo.getDone());
        database.update("family_schedule",values,whereclause,whereargs);
        return "SUCCESS";
    }
}
