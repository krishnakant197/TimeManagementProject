package com.techinfu.worktimemanagement.helper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;
import com.techinfu.worktimemanagement.pojo.ProfilePojo;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class HealthSchd_Helper {


    public ArrayList getScheduleList(SQLiteDatabase database) {
        ArrayList productList= new ArrayList<>();
        try{
            productList.clear();
            String selectQuery = "select Id,Title,StartTime,EndTime,Priority,Alarm,Done,Date from health_schedule ORDER BY Id";
            Cursor mcursor = database.rawQuery(selectQuery, null);
            if (mcursor.moveToFirst()) {
                do {
                    HealthSchdPojo healthSchdPojo=new HealthSchdPojo();
                    healthSchdPojo.setId(mcursor.getInt(mcursor.getColumnIndexOrThrow("Id")));
                    healthSchdPojo.setTitle(mcursor.getString(mcursor.getColumnIndexOrThrow("Title")));
                    healthSchdPojo.setDate(mcursor.getString(mcursor.getColumnIndexOrThrow("Date")));
                    healthSchdPojo.setStartTime( mcursor.getString(mcursor.getColumnIndexOrThrow("StartTime")));
                    healthSchdPojo.setEndTime(mcursor.getString(mcursor.getColumnIndexOrThrow("EndTime")));
                    healthSchdPojo.setDone(mcursor.getString(mcursor.getColumnIndexOrThrow("Done")));
                    healthSchdPojo.setPriority(mcursor.getInt(mcursor.getColumnIndexOrThrow("Priority")));
                    healthSchdPojo.setAlarm(mcursor.getString(mcursor.getColumnIndexOrThrow("Alarm")));
                    productList.add(healthSchdPojo);
                } while (mcursor.moveToNext());
            }
            mcursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productList;
    }


    //This method will add new Product
    public String addEvent(SQLiteDatabase database, HealthSchdPojo healthSchdPojo){
        ContentValues values = new ContentValues();
        values.put("Title", healthSchdPojo.getTitle());
        values.put("Date", healthSchdPojo.getDate());
        values.put("StartTime",healthSchdPojo.getStartTime());
        values.put("EndTime",healthSchdPojo.getEndTime());
        values.put("Priority",healthSchdPojo.getPriority());
        database.insert("health_schedule", null, values);
        return "SUCCESS";
    }

    //This method will add new Product
    public String updateEvent(SQLiteDatabase database,HealthSchdPojo healthSchdPojo){
        String whereclause = "Id=?";
        String[] whereargs = {String.valueOf(healthSchdPojo.getId())};
        ContentValues values = new ContentValues();
        values.put("Done", healthSchdPojo.getDone());
        database.update("health_schedule",values,whereclause,whereargs);
        return "SUCCESS";
    }
}
