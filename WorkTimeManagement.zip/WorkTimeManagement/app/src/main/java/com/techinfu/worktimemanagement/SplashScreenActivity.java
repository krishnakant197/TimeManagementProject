package com.techinfu.worktimemanagement;

import static com.techinfu.worktimemanagement.helper.DB_Helper.DATABASE_VERSION;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import com.techinfu.worktimemanagement.helper.DB_Helper;
import com.techinfu.worktimemanagement.home.AppHomeActivity;

public class SplashScreenActivity extends AppCompatActivity {

    private int SPLASH_SCREEN_TIME_OUT = 3000;
    private static final int PERMISSION_REQUEST_CODE = 100;
    private Context context;
    private DB_Helper db_helperApp;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen_activity);
        context=SplashScreenActivity.this;
        db_helperApp =new DB_Helper(context,null,null,1);
        copyDatabase();

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                moveToNextActivity();
            }
        }, SPLASH_SCREEN_TIME_OUT);
    }

    private void copyDatabase(){
        try{
            db_helperApp.createDataBase();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void moveToNextActivity(){
        try{
            Intent i = new Intent(SplashScreenActivity.this, AppHomeActivity.class);
            startActivity(i);
            finish();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}