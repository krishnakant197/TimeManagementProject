package com.techinfu.worktimemanagement;

import android.app.DatePickerDialog;
import android.content.Context;
import android.widget.DatePicker;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;


import com.techinfu.worktimemanagement.pojo.CalendarPojo;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Date_Calendar extends AppCompatActivity {


    //This method will return year,month,and day
    public CalendarPojo getYearMonthDay(){
        CalendarPojo calendarPojo=new CalendarPojo();
        try{
            Calendar calendar = Calendar.getInstance();
            calendarPojo.setYear(calendar.get(Calendar.YEAR));
            calendarPojo.setMonth(calendar.get(Calendar.MONTH));
            calendarPojo.setDay(calendar.get(Calendar.DAY_OF_MONTH));
        } catch (Exception e) {
            e.printStackTrace();
        }
        return calendarPojo;
    }

    public String getCurrentDate()
    {
        Date c = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat("dd-MM-yyyy");
        String formattedDate = df.format(c);
        return formattedDate;
    }


    public String getCurrentDateAndTime()
    {
        Date currentTime = Calendar.getInstance().getTime();
        SimpleDateFormat df = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
        //SimpleDateFormat df = new SimpleDateFormat( "dd-MM-yyyy h:mm:ss a");
        String formatTime = df.format(currentTime);
        return formatTime;
    }


    public String getCurrent12Date()
    {
        Date currentTime = Calendar.getInstance().getTime();
        //SimpleDateFormat df = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
        SimpleDateFormat df = new SimpleDateFormat( "dd-MM-yyyy h:mm:ss a");
        String formatTime = df.format(currentTime);
        return formatTime;
    }


    public String convertMonthNumber(int monthNumber)
    {
        String monthName;
        switch(monthNumber){
            case 1:
                monthName = "01";
                break;
            case 2 :
                monthName = "02";
                break;
            case 3 :
                monthName = "03";
                break;
            case 4 :
                monthName = "04";
                break;
            case 5 :
                monthName = "05";
                break;
            case 6 :
                monthName = "06";
                break;
            case 7 :
                monthName = "07";
                break;
            case 8 :
                monthName = "08";
                break;
            case 9 :
                monthName = "09";
                break;
            case 10 :
                monthName = "10";
                break;
            case 11 :
                monthName = "11";
                break;
            case 12 :
                monthName = "12";
                break;
            default:
                monthName="null";
                break;
        }

        return monthName;
    }


    public Date stringToDate(String dateString){
        Date date = null;
        SimpleDateFormat format = new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
        try {
            date = format.parse(dateString);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }


    public String changeDateFormat(String date){
        try{
            SimpleDateFormat spf=new SimpleDateFormat( "yyyy-MM-dd HH:mm:ss");
            Date newDate=spf.parse(date);
            spf= new SimpleDateFormat("dd MMM yyyy");
            date = spf.format(newDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    public void setDateOnEditText(final EditText editText, Context context){
        try{
            CalendarPojo calendarPojo = new Date_Calendar().getYearMonthDay();
            DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                    new DatePickerDialog.OnDateSetListener() {
                        @Override
                        public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                            String monthName=new Date_Calendar().convertMonthNumber(month+1);
                            editText.setText(day + "-" + monthName+ "-" + year);
                        }
                    }, calendarPojo.getYear(), calendarPojo.getMonth(), calendarPojo.getDay());
            //datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
            datePickerDialog.show();
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }


}
