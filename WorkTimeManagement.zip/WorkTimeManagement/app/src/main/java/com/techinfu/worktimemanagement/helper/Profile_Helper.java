package com.techinfu.worktimemanagement.helper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;
import com.techinfu.worktimemanagement.pojo.ProfilePojo;
import com.techinfu.worktimemanagement.profile.ProfileActivity;

public class Profile_Helper {

    //This method will add new Product
    public String addProfile(SQLiteDatabase database, ProfilePojo profilePojo){
        ContentValues values = new ContentValues();
        values.put("Name", profilePojo.getName());
        values.put("Mobile", profilePojo.getMobile());
        values.put("Email",profilePojo.getEmail());
        database.insert("profile", null, values);
        return "SUCCESS";
    }


    //This method will add new Product
    public String updateProfile(SQLiteDatabase database,ProfilePojo profilePojo){
        String whereclause = "Id=?";
        String[] whereargs = {String.valueOf(1)};
        ContentValues values = new ContentValues();
        values.put("Name", profilePojo.getName());
        values.put("Mobile", profilePojo.getMobile());
        values.put("Email",profilePojo.getEmail());
        database.update("profile",values,whereclause,whereargs);
        return "SUCCESS";
    }

    public ProfilePojo getCustomerDetails(SQLiteDatabase dbConn) {
        ProfilePojo profilePojo = null;
        String selectQuery = "select Name,Mobile,Email from profile";
        Cursor mcursor = dbConn.rawQuery(selectQuery, null);
        if (mcursor.moveToFirst()) {
            profilePojo=new ProfilePojo();
            profilePojo.setName(mcursor.getString(mcursor.getColumnIndexOrThrow("Name")));
            profilePojo.setMobile(mcursor.getString(mcursor.getColumnIndexOrThrow("Mobile")));
            profilePojo.setEmail(mcursor.getString(mcursor.getColumnIndexOrThrow("Email")));
        }
        mcursor.close();
        return profilePojo;
    }
}
