package com.techinfu.worktimemanagement.helper;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.techinfu.worktimemanagement.pojo.WorkSchdPojo;

import java.util.ArrayList;

public class WorkSchd_Helper {
    public ArrayList getScheduleList(SQLiteDatabase database) {
        ArrayList productList= new ArrayList<>();
        try{
            productList.clear();
            String selectQuery = "select Id,Title,StartTime,EndTime,Priority,Alarm,Done,Date from work_schedule ORDER BY Id";
            Cursor mcursor = database.rawQuery(selectQuery, null);
            if (mcursor.moveToFirst()) {
                do {
                    WorkSchdPojo workSchdPojo=new WorkSchdPojo();
                    workSchdPojo.setId(mcursor.getInt(mcursor.getColumnIndexOrThrow("Id")));
                    workSchdPojo.setTitle(mcursor.getString(mcursor.getColumnIndexOrThrow("Title")));
                    workSchdPojo.setDate(mcursor.getString(mcursor.getColumnIndexOrThrow("Date")));
                    workSchdPojo.setStartTime( mcursor.getString(mcursor.getColumnIndexOrThrow("StartTime")));
                    workSchdPojo.setEndTime(mcursor.getString(mcursor.getColumnIndexOrThrow("EndTime")));
                    workSchdPojo.setDone(mcursor.getString(mcursor.getColumnIndexOrThrow("Done")));
                    workSchdPojo.setPriority(mcursor.getInt(mcursor.getColumnIndexOrThrow("Priority")));
                    workSchdPojo.setAlarm(mcursor.getString(mcursor.getColumnIndexOrThrow("Alarm")));
                    productList.add(workSchdPojo);
                } while (mcursor.moveToNext());
            }
            mcursor.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return productList;
    }

    //This method will add new Product
    public String addEvent(SQLiteDatabase database, WorkSchdPojo workSchdPojo){
        ContentValues values = new ContentValues();
        values.put("Title", workSchdPojo.getTitle());
        values.put("Date", workSchdPojo.getDate());
        values.put("StartTime",workSchdPojo.getStartTime());
        values.put("EndTime",workSchdPojo.getEndTime());
        values.put("Priority",workSchdPojo.getPriority());
        database.insert("work_schedule", null, values);
        return "SUCCESS";
    }

    //This method will add new Product
    public String updateEvent(SQLiteDatabase database,WorkSchdPojo workSchdPojo){
        String whereclause = "Id=?";
        String[] whereargs = {String.valueOf(workSchdPojo.getId())};
        ContentValues values = new ContentValues();
        values.put("Done", workSchdPojo.getDone());
        database.update("work_schedule",values,whereclause,whereargs);
        return "SUCCESS";
    }
}
