package com.techinfu.worktimemanagement.profile;

import static com.techinfu.worktimemanagement.helper.DB_Helper.DATABASE_VERSION;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

import com.google.android.material.textfield.TextInputEditText;
import com.techinfu.worktimemanagement.R;
import com.techinfu.worktimemanagement.helper.DB_Helper;
import com.techinfu.worktimemanagement.helper.Profile_Helper;
import com.techinfu.worktimemanagement.pojo.ProfilePojo;

public class ProfileActivity extends AppCompatActivity {

    private SQLiteDatabase dbConn;
    private Context cntx;
    private Toolbar customerEntryToolBar;
    private TextInputEditText CustomerNameTextInputET, CustomerMobileTextInputET, CustomerEmailTextInputET;
    private Button SaveCustomerBTN;
    public boolean isCustomerUpdates =false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        cntx = ProfileActivity.this;
        initViewObject();
        displayCustomerDetail();
        customerEntryToolBar();
        SaveCustomerBTN.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                String message =saveCustomer();
                if(message.equals("SUCCESS")){
                    successDialog();
                }else{
                    failureDialog();
                }
            }
        });
    }

    //Initialize the Views Objects
    private void initViewObject(){
        try{
            customerEntryToolBar= findViewById(R.id.custEntryToolbar);
            CustomerNameTextInputET =findViewById(R.id.textinputEditTextCustomerName);
            CustomerMobileTextInputET = findViewById(R.id.textinputEditTextCustomerMobile);
            CustomerEmailTextInputET = findViewById(R.id.textinputEditTextCustomerEmail);
            SaveCustomerBTN = findViewById(R.id.b_savecustomer);
        } catch (Exception exception) {
            exception.printStackTrace();
        }
    }

    // Set the Toolbar
    private void customerEntryToolBar(){
        try{
            setSupportActionBar(customerEntryToolBar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getResources().getString(R.string.profile));
            customerEntryToolBar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    //Populate the Details of Customer For update
    private void displayCustomerDetail(){
        try{
            dbConn= new DB_Helper(this,null,null,DATABASE_VERSION).getWritableDatabase();
            dbConn.beginTransaction();
            ProfilePojo profilePojo=new Profile_Helper().getCustomerDetails(dbConn);
            if(profilePojo!=null){
                SaveCustomerBTN.setText(R.string.Update);
                isCustomerUpdates = true;
                CustomerNameTextInputET.setText(profilePojo.getName());
                CustomerMobileTextInputET.setText(profilePojo.getMobile());
                CustomerEmailTextInputET.setText(profilePojo.getEmail());
            }
            dbConn.setTransactionSuccessful();
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            dbConn.endTransaction();
        }
    }

    private String saveCustomer(){
        String message="";
        try{
            dbConn = new DB_Helper(cntx,null,null,DATABASE_VERSION).getWritableDatabase();
            try{
                dbConn.beginTransaction();
                message ="FAILED";
                if(!isCustomerUpdates) {
                    message=new Profile_Helper().addProfile(dbConn,setCustomerPojo());
                }else{
                    message= new Profile_Helper().updateProfile(dbConn,setCustomerPojo());
                }
                dbConn.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                dbConn.endTransaction();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }


    //Setting the CustomerPojo
    private ProfilePojo setCustomerPojo() {
        ProfilePojo profilePojo = new ProfilePojo();
        try{
            profilePojo.setName(CustomerNameTextInputET.getText().toString());
            profilePojo.setMobile(CustomerMobileTextInputET.getText().toString());
            profilePojo.setEmail(CustomerEmailTextInputET.getText().toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
        return profilePojo;
    }

    private void successDialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(cntx);
        builder1.setMessage("Details saved successfully.");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void failureDialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(cntx);
        builder1.setMessage("Failed to save details...");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "RETRY",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        builder1.setNegativeButton(
                "CLOSE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }
}