package com.techinfu.worktimemanagement.home;

import static com.techinfu.worktimemanagement.helper.DB_Helper.DATABASE_VERSION;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.techinfu.worktimemanagement.AddNewEventActivity;
import com.techinfu.worktimemanagement.R;
import com.techinfu.worktimemanagement.adapter.FamilySchdListAdapter;
import com.techinfu.worktimemanagement.adapter.HealthSchdListAdapter;
import com.techinfu.worktimemanagement.adapter.WorkSchdListAdapter;
import com.techinfu.worktimemanagement.helper.DB_Helper;
import com.techinfu.worktimemanagement.helper.FamilySchd_Helper;
import com.techinfu.worktimemanagement.helper.HealthSchd_Helper;
import com.techinfu.worktimemanagement.helper.WorkSchd_Helper;
import com.techinfu.worktimemanagement.profile.ProfileActivity;

import java.util.ArrayList;

public class AppHomeActivity extends AppCompatActivity {

   private Context context;
   private RecyclerView healthPlanListRCV,workPlanListRCV,familyPlanListRCV;
   private Button addNewEvenBTN;
   private Toolbar mTopToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_app_home);
        context= AppHomeActivity.this;
        initializeViews();
        AppHomeToolbar();
        setButtonListener();
        displayList();
    }

    private void setButtonListener() {
        addNewEvenBTN.setOnClickListener(view -> {
            try{
                Intent i = new Intent(context, AddNewEventActivity.class);
                startActivity(i);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    private void initializeViews(){
        try{
            healthPlanListRCV=findViewById(R.id.morningRCV);
            workPlanListRCV=findViewById(R.id.workRCV);
            familyPlanListRCV=findViewById(R.id.familyRCV);
            mTopToolbar=findViewById(R.id.appHomeToolbar);
            addNewEvenBTN=findViewById(R.id.buttonAddNewEvent);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private  void AppHomeToolbar(){
        try{
            setSupportActionBar(mTopToolbar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getResources().getString(R.string.app_name));
            mTopToolbar.setNavigationOnClickListener(view -> finish());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private void displayList(){
        try{
            SQLiteDatabase dbConn = new DB_Helper(this,null,null,DATABASE_VERSION).getWritableDatabase();
            try{
                dbConn.beginTransaction();
                ArrayList healthSchdList = new HealthSchd_Helper().getScheduleList(dbConn);
                ArrayList workSchdList = new WorkSchd_Helper().getScheduleList(dbConn);
                ArrayList familySchdList = new FamilySchd_Helper().getScheduleList(dbConn);

                populateHealthList(healthSchdList);
                populateWorkList(workSchdList);
                populateFamilyList(familySchdList);
                dbConn.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                dbConn.endTransaction();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void populateHealthList(ArrayList healthSchdList) {
        HealthSchdListAdapter healthSchdListAdapter = new HealthSchdListAdapter(healthSchdList,context);
        healthPlanListRCV.setHasFixedSize(true);

        healthPlanListRCV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        //healthPlanListRCV.setLayoutManager(new LinearLayoutManager(this));
        healthPlanListRCV.setAdapter(healthSchdListAdapter);

    }

    private void populateWorkList(ArrayList workSchdList) {
        WorkSchdListAdapter workSchdListAdapter = new WorkSchdListAdapter(workSchdList,context);
        workPlanListRCV.setHasFixedSize(true);
        workPlanListRCV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        workPlanListRCV.setAdapter(workSchdListAdapter);
    }

    private void populateFamilyList(ArrayList familySchdList) {
        FamilySchdListAdapter familySchdListAdapter = new FamilySchdListAdapter(familySchdList,context);
        familyPlanListRCV.setHasFixedSize(true);
        familyPlanListRCV.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, true));
        familyPlanListRCV.setAdapter(familySchdListAdapter);
    }


    @Override
    public void onBackPressed() {
        try{
            new AlertDialog.Builder(this)
                    .setMessage("Are you sure you want to exit?")
                    .setCancelable(false)
                    .setPositiveButton("Yes", (dialog, id) -> {
                        try{
                            AppHomeActivity.super.onBackPressed();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    })
                    .setNegativeButton("No", null)
                    .show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.home_page_menu, menu);
        final MenuItem menuItem = menu.findItem(R.id.action_profile);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_profile) {
            try{
                Intent intent = new Intent(AppHomeActivity.this, ProfileActivity.class);
                startActivity(intent);
            } catch (Exception e) {
                e.printStackTrace();
            }
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}