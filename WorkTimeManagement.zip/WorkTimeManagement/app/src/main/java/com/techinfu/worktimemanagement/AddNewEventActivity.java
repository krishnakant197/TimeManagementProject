package com.techinfu.worktimemanagement;

import static com.techinfu.worktimemanagement.helper.DB_Helper.DATABASE_VERSION;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TimePicker;

import com.google.android.material.textfield.TextInputEditText;
import com.techinfu.worktimemanagement.adapter.WorkSchdListAdapter;
import com.techinfu.worktimemanagement.helper.DB_Helper;
import com.techinfu.worktimemanagement.helper.FamilySchd_Helper;
import com.techinfu.worktimemanagement.helper.HealthSchd_Helper;
import com.techinfu.worktimemanagement.helper.Profile_Helper;
import com.techinfu.worktimemanagement.helper.WorkSchd_Helper;
import com.techinfu.worktimemanagement.pojo.CalendarPojo;
import com.techinfu.worktimemanagement.pojo.FamilySchdPojo;
import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;
import com.techinfu.worktimemanagement.pojo.ProfilePojo;
import com.techinfu.worktimemanagement.pojo.WorkSchdPojo;

import java.util.Calendar;
import java.util.List;

public class AddNewEventActivity extends AppCompatActivity {
    private Context context;
    private Spinner prioritySP,eventTypeSP;
    private Toolbar customerEntryToolBar;
    private TextInputEditText titleTextInputET, dateTextInputET, startTimeTextInputET,endTimeTextInputET;
    private ImageView dateIV;
    private Button saveBtn;

    private String eventType="",priority="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_event);
        context=AddNewEventActivity.this;
        initializeViews();
        setSpinner();
        customerEntryToolBar();
        setListeners();
        saveDetails();
    }

    private void saveDetails() {
        saveBtn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                try {
                    if(titleTextInputET.getText().toString().trim().equals("")){
                        validationDialog();
                    }else{
                        if(eventType.equals("HEALTH")) {
                            HealthSchdPojo healthSchdPojo = setHealthPojo();
                            saveHelth(healthSchdPojo);
                        }else if(eventType.equals("WORK")) {
                            WorkSchdPojo healthSchdPojo = setWorkPojo();
                            saveWork(healthSchdPojo);
                        }else if(eventType.equals("FAMILY")) {
                            FamilySchdPojo healthSchdPojo = setFamilyPojo();
                            saveFamily(healthSchdPojo);
                        }else {
                            failureDialog();
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    private void setListeners() {
        dateIV.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CalendarPojo calendarPojo = new Date_Calendar().getYearMonthDay();
                DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                String monthName=new Date_Calendar().convertMonthNumber(month+1);
                                dateTextInputET.setText(day + "-" + monthName+ "-" + year);
                            }
                        }, calendarPojo.getYear(), calendarPojo.getMonth(), calendarPojo.getDay());
                //datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });


        dateTextInputET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                CalendarPojo calendarPojo = new Date_Calendar().getYearMonthDay();
                DatePickerDialog datePickerDialog = new DatePickerDialog(context,
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                String monthName=new Date_Calendar().convertMonthNumber(month+1);
                                dateTextInputET.setText(day + "-" + monthName+ "-" + year);
                            }
                        }, calendarPojo.getYear(), calendarPojo.getMonth(), calendarPojo.getDay());
                //datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

        startTimeTextInputET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        startTimeTextInputET.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Start Time");
                mTimePicker.show();
            }
        });

        endTimeTextInputET.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(context, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        endTimeTextInputET.setText( selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select End Time");
                mTimePicker.show();
            }
        });

    }

    private void initializeViews() {
        customerEntryToolBar= findViewById(R.id.custEntryToolbar);
        prioritySP=findViewById(R.id.spinnerPriority);
        eventTypeSP=findViewById(R.id.spinnerEventType);
        titleTextInputET=findViewById(R.id.textinputEditTextTitle);
        dateTextInputET=findViewById(R.id.textinputEditTextDate);
        startTimeTextInputET=findViewById(R.id.textinputEditTextStartTime);
        endTimeTextInputET=findViewById(R.id.textinputEditTextEndTime);
        dateIV=findViewById(R.id.imageViewDate);
        saveBtn=findViewById(R.id.b_AddNewEvent);
    }

    // Set the Toolbar
    private void customerEntryToolBar(){
        try{
            setSupportActionBar(customerEntryToolBar);
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setDisplayShowHomeEnabled(true);
            getSupportActionBar().setTitle(getResources().getString(R.string.add_new_event));
            customerEntryToolBar.setNavigationOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    finish();
                }
            });
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setSpinner(){
        String[] list = { "DEFAULT", "HIGH", "MEDIUM", "LOW"};
        ArrayAdapter<String> spinnerArrayAdapter = new ArrayAdapter<String> (context, android.R.layout.simple_spinner_item, list);
        spinnerArrayAdapter.setDropDownViewResource(android.R.layout .simple_spinner_dropdown_item);
        prioritySP.setAdapter(spinnerArrayAdapter);
        prioritySP.setOnItemSelectedListener(new  AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long Id) {
                Object item = adapterView.getItemAtPosition(i);
                priority=item.toString();

            }
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });


        String[] list2 = { "HEALTH", "WORK", "FAMILY"};
        ArrayAdapter<String> spinnerArrayAdapter2 = new ArrayAdapter<String> (context, android.R.layout.simple_spinner_item, list2);
        spinnerArrayAdapter2.setDropDownViewResource(android.R.layout .simple_spinner_dropdown_item);
        eventTypeSP.setAdapter(spinnerArrayAdapter2);
        eventTypeSP.setOnItemSelectedListener(new  AdapterView.OnItemSelectedListener() {
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long Id) {
                Object item = adapterView.getItemAtPosition(i);
                eventType=item.toString();
            }
            public void onNothingSelected(AdapterView<?> arg0) {
            }
        });
    }

    private void failureDialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage("Failed to save details...");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "RETRY",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        builder1.setNegativeButton(
                "CLOSE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void validationDialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage("Enter title...");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        builder1.setNegativeButton(
                "",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        //dialog.cancel();
                        //finish();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }

    private void successDialog(){
        AlertDialog.Builder builder1 = new AlertDialog.Builder(context);
        builder1.setMessage("Details saved successfully.");
        builder1.setCancelable(true);

        builder1.setPositiveButton(
                "ADD NEW",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                        finish();
                    }
                });

        builder1.setNegativeButton(
                "CLOSE",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        dialog.cancel();
                    }
                });

        AlertDialog alert11 = builder1.create();
        alert11.show();
    }



    //Setting the CustomerPojo
    private HealthSchdPojo setHealthPojo() {
        HealthSchdPojo healthSchdPojo = new HealthSchdPojo();
        try{
            healthSchdPojo.setTitle(titleTextInputET.getText().toString());
            healthSchdPojo.setDate(dateTextInputET.getText().toString());
            healthSchdPojo.setStartTime(startTimeTextInputET.getText().toString());
            healthSchdPojo.setEndTime(endTimeTextInputET.getText().toString());
            healthSchdPojo.setDone("No");

            if(priority.equals("DEFAULT")){
                healthSchdPojo.setPriority(3);

            }else if(priority.equals("HIGH")){
                healthSchdPojo.setPriority(1);

            }else if(priority.equals("MEDIUM")){
                healthSchdPojo.setPriority(2);
            }else if(priority.equals("LOW")){
                healthSchdPojo.setPriority(3);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return healthSchdPojo;
    }


    //Setting the CustomerPojo
    private WorkSchdPojo setWorkPojo() {
        WorkSchdPojo workSchdPojo = new WorkSchdPojo();
        try{
            workSchdPojo.setTitle(titleTextInputET.getText().toString());
            workSchdPojo.setDate(dateTextInputET.getText().toString());
            workSchdPojo.setStartTime(startTimeTextInputET.getText().toString());
            workSchdPojo.setEndTime(endTimeTextInputET.getText().toString());
            workSchdPojo.setDone("No");
            if(priority.equals("DEFAULT")){
                workSchdPojo.setPriority(1);

            }else if(priority.equals("HIGH")){
                workSchdPojo.setPriority(2);

            }else if(priority.equals("MEDIUM")){
                workSchdPojo.setPriority(3);
            }else if(priority.equals("LOW")){
                workSchdPojo.setPriority(4);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return workSchdPojo;
    }


    //Setting the CustomerPojo
    private FamilySchdPojo setFamilyPojo() {
        FamilySchdPojo familySchdPojo = new FamilySchdPojo();
        try{
            familySchdPojo.setTitle(titleTextInputET.getText().toString());
            familySchdPojo.setDate(dateTextInputET.getText().toString());
            familySchdPojo.setStartTime(startTimeTextInputET.getText().toString());
            familySchdPojo.setEndTime(endTimeTextInputET.getText().toString());
            familySchdPojo.setDone("No");

            if(priority.equals("DEFAULT")){
                familySchdPojo.setPriority(1);

            }else if(priority.equals("HIGH")){
                familySchdPojo.setPriority(2);

            }else if(priority.equals("MEDIUM")){
                familySchdPojo.setPriority(3);
            }else if(priority.equals("LOW")){
                familySchdPojo.setPriority(4);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return familySchdPojo;
    }



    private String saveHelth(HealthSchdPojo healthSchdPojo){
        String message="";
        try{
            SQLiteDatabase dbConn = new DB_Helper(context,null,null,DATABASE_VERSION).getWritableDatabase();
            try{
                dbConn.beginTransaction();
                message ="FAILED";
                message = new HealthSchd_Helper().addEvent(dbConn,healthSchdPojo);
                if(message.equals("SUCCESS")){
                    successDialog();
                }else{
                    failureDialog();
                }
                dbConn.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                dbConn.endTransaction();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }

    private String saveWork(WorkSchdPojo workSchdPojo){
        String message="";
        try{
            SQLiteDatabase dbConn = new DB_Helper(context,null,null,DATABASE_VERSION).getWritableDatabase();
            try{
                dbConn.beginTransaction();
                message ="FAILED";
                message= new WorkSchd_Helper().addEvent(dbConn,workSchdPojo);
                if(message.equals("SUCCESS")){
                    successDialog();
                }else{
                    failureDialog();
                }
                dbConn.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                dbConn.endTransaction();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }


    private String saveFamily(FamilySchdPojo familySchdPojo){
        String message="";
        try{
            SQLiteDatabase dbConn = new DB_Helper(context,null,null,DATABASE_VERSION).getWritableDatabase();
            try{
                dbConn.beginTransaction();
                message ="FAILED";
                message= new FamilySchd_Helper().addEvent(dbConn,familySchdPojo);
                if(message.equals("SUCCESS")){
                    successDialog();
                }else{
                    failureDialog();
                }
                dbConn.setTransactionSuccessful();
            } catch (Exception e) {
                e.printStackTrace();
            }finally {
                dbConn.endTransaction();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return message;
    }


}