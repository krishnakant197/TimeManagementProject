package com.techinfu.worktimemanagement.adapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Filter;
import android.widget.Filterable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;


import com.techinfu.worktimemanagement.R;
import com.techinfu.worktimemanagement.helper.HealthSchd_Helper;
import com.techinfu.worktimemanagement.pojo.HealthSchdPojo;

import java.io.File;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class HealthSchdListAdapter extends RecyclerView.Adapter<HealthSchdListAdapter.ViewHolder> {
    private final ArrayList<HealthSchdPojo> healthSchdList;
    private Context context;

    public HealthSchdListAdapter(ArrayList<HealthSchdPojo> ProductListReceived,Context context) {
        this.healthSchdList = ProductListReceived;
        this.context=context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.health_schd_list_item, parent, false);
        return new ViewHolder(listItem);
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final  ViewHolder holder, int position) {
        try{
            final HealthSchdPojo healthSchdPojo = healthSchdList.get(position);
            holder.titleTV.setText(healthSchdPojo.getTitle());
            holder.dateTV.setText(healthSchdPojo.getDate());
            holder.timelineTV.setText("From "+healthSchdPojo.getStartTime()+" To "+healthSchdPojo.getEndTime());
            holder.priorityTV.setText(setPriority(healthSchdPojo.getPriority()));

            String isDone = healthSchdPojo.getDone();
            if(isDone==null){
                isDone="No";
            }
            if(isDone.equals("Yes")){
                holder.doneCB.setChecked(true);
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_gray));
            }else{
                holder.doneCB.setChecked(false);
            }

            int priority = healthSchdPojo.getPriority();
            if(priority==1){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_red));
            }else if (priority==2){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_yellow));
            }else{
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_green));
            }


         /*   holder.doneCB.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try{

                        HealthSchdPojo healthSchdPojo1 =new HealthSchdPojo();
                       if(holder.doneCB.isChecked()){
                          healthSchdPojo1.setDone("Yes");
                       }else{
                           healthSchdPojo1.setDone("No");
                       }
                       new HealthSchd_Helper().up
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });*/

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String setPriority(int priority) {
        String name ="";
        if(priority==3){
            name="LOW";
        }else if(priority==1){
            name="HIGH";
        }else if(priority==2){
            name="MEDIUM";
        }
        return name;
    }

    @Override
    public int getItemCount() {
        return healthSchdList.size();
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView titleTV,dateTV,timelineTV,priorityTV;
        private CheckBox doneCB;
        private CardView itemCardView;
        ViewHolder(View itemView) {
            super(itemView);
            this.titleTV=itemView.findViewById(R.id.textViewTitile);
            this.dateTV = itemView.findViewById(R.id.textViewDate);
            this.timelineTV = itemView.findViewById(R.id.textViewTimeLine);
            this.priorityTV =itemView.findViewById(R.id.textViewPriority);
            this.doneCB = itemView.findViewById(R.id.checkBox);
            this.itemCardView = itemView.findViewById(R.id.itemCardView);
        }
    }


}

