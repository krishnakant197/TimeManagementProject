package com.techinfu.worktimemanagement.adapter;


import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.Filterable;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.techinfu.worktimemanagement.R;
import com.techinfu.worktimemanagement.pojo.FamilySchdPojo;
import com.techinfu.worktimemanagement.pojo.WorkSchdPojo;

import java.util.ArrayList;

public class WorkSchdListAdapter extends RecyclerView.Adapter<WorkSchdListAdapter.ViewHolder> {
    private final ArrayList<WorkSchdPojo> workschdList;
    private Context context;

    public WorkSchdListAdapter(ArrayList<WorkSchdPojo> listReceived,Context context) {
        this.workschdList = listReceived;
        this.context=context;
    }

    @NonNull
    @Override
    public WorkSchdListAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View listItem= layoutInflater.inflate(R.layout.health_schd_list_item, parent, false);
        return new WorkSchdListAdapter.ViewHolder(listItem);
    }


    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final WorkSchdListAdapter.ViewHolder holder, int position) {
        try{
            final WorkSchdPojo workSchdPojo = workschdList.get(position);
            holder.titleTV.setText(workSchdPojo.getTitle());
            holder.dateTV.setText(workSchdPojo.getDate());
            holder.timelineTV.setText("From "+workSchdPojo.getStartTime()+" To "+workSchdPojo.getEndTime());
            holder.priorityTV.setText(setPriority(workSchdPojo.getPriority()));

            String isDone = workSchdPojo.getDone();
            if(isDone==null){
                isDone="No";
            }

            if(isDone.equals("Yes")){
                holder.doneCB.setChecked(true);
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_gray));
            }else{
                holder.doneCB.setChecked(false);
            }

            int priority = workSchdPojo.getPriority();
            if(priority==1){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_red));
            }else if (priority==2){
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_yellow));
            }else{
                holder.itemCardView.setBackgroundColor(context.getResources().getColor(R.color.light_green));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public int getItemCount() {
        return workschdList.size();
    }
    private String setPriority(int priority) {
        String name ="";
        if(priority==3){
            name="LOW";
        }else if(priority==1){
            name="HIGH";
        }else if(priority==2){
            name="MEDIUM";
        }
        return name;
    }



    static class ViewHolder extends RecyclerView.ViewHolder {
        private TextView titleTV,dateTV,timelineTV,priorityTV;
        private CheckBox doneCB;
        private CardView itemCardView;
        ViewHolder(View itemView) {
            super(itemView);
            this.titleTV=itemView.findViewById(R.id.textViewTitile);
            this.dateTV = itemView.findViewById(R.id.textViewDate);
            this.timelineTV = itemView.findViewById(R.id.textViewTimeLine);
            this.priorityTV =itemView.findViewById(R.id.textViewPriority);
            this.doneCB = itemView.findViewById(R.id.checkBox);
            this.itemCardView = itemView.findViewById(R.id.itemCardView);
        }
    }

}

